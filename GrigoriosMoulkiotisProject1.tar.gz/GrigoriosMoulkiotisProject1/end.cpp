#include "sniffer.hpp"

extern char* ibuff[6];
extern pid_t lpid;
extern queue<workers> wk_queue;
extern map<pid_t, insert_str> fifos;

void end(int signum){
    //Ending the Manager and killing the childs
    while(!wk_queue.empty()){
        workers wk = wk_queue.front();
        kill(wk.pid,SIGKILL);
        wk_queue.pop();
    }
    kill(lpid,SIGKILL);
    exit(0);
}

void collect_workers(int sig){
    int workerpid;
    int workerstatus;
    while((workerpid = waitpid(-1,&workerstatus,WNOHANG|WUNTRACED)) > 0){ 
        auto itr = fifos.find(workerpid);
        printf("malakas:%d\n",workerpid);
        cout << itr->second.name << endl;
        workers wk_new = {workerpid,0,itr->second.name};
        wk_queue.push(wk_new);
        printf("end!\n");              
    }   
    
}